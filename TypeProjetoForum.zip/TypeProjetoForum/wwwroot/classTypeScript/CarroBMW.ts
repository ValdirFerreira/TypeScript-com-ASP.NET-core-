﻿// Referencia Tipo de carro
/// <reference path="enumtipocarro.ts" />
// Importação da referencia da classe carro utilizada
/// <reference path="carro.js" />



// Function utilizando a classe carro
function CriarNomeCarro() {

    let novoCarro = new Carro("BMW");
    novoCarro.tipocarro = TipoCarro.CarroPasseio;

    // Carregando Div utilizando o DOM 
    document.getElementById("DivMensagem").innerHTML = novoCarro.criarNomeCarro();


    // Carregando a Div Utilizando JQuery
    $("#DivMensagem").html(novoCarro.criarNomeCarro());



    let novoCaminhao = new Caminao("V12");
    var nomeCaminão = novoCaminhao.criarNomeCarro();
    novoCaminhao.quantidadeEixos = 4;
    novoCaminhao.tipocarro = TipoCarro.Caminhão;


}