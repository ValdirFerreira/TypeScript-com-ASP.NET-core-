﻿/// <reference path="EnumTipoCarro.ts" />
// Referencia do tipo de carro



class Carro {
    private nome: string;

    tipocarro : TipoCarro;
    constructor(nomecarro: string) {
        this.nome = nomecarro;
    }

    public criarNomeCarro(): string {
        return "O Carro chama : " + this.nome;
    }


}

// Herança
class Caminao extends  Carro
{   
    quantidadeEixos: number;
}

// Abstratas
class Trator extends Carro {

    constructor() {
        super('Trator MOST-TIPE'); // constructors in derived classes must call super()
    }
}



// Criação da Interface

interface ICalculadora {
    numero1: number;
    numero2: number;
    resposta?: number;
    showX();
}

class Somar implements ICalculadora {
    numero1: number = 1;
    numero2: number = 2;

    resposta: number = this.numero1 + this.numero2;
    showX() {
        
        console.log(this.resposta);
    }
}