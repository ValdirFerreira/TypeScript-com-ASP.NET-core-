/// <reference path="EnumTipoCarro.ts" />
// Referencia do tipo de carro
var Carrro = /** @class */ (function () {
    function Carrro(nomecarro) {
        this.nome = nomecarro;
    }
    Carrro.prototype.criarNomeCarro = function () {
        return "O Carro chama : " + this.nome;
    };
    return Carrro;
}());
//# sourceMappingURL=carro.js.map