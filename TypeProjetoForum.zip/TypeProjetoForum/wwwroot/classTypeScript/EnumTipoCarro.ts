﻿enum TipoCarro {
    CarroPasseio = 1,
    Caminhão = 2,
    Onibus = 3
}